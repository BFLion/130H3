#include <vector>
#include <string>
#include <iostream>
#include "common.h"

void Rasterize(Pixel* pixels, int width, int height, const std::vector<Triangle>& tris)
{
    std::cout<<"TODO: implement rasterization"<<std::endl;
}
